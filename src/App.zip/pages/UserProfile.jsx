import React from "react";

const UserProfile = () => {
  return <div></div>;
};

export default UserProfile;
