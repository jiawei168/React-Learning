import React from "react";

const NotFound = () => {
  return (
    <div>
      <h2>页面未找到</h2>
    </div>
  );
};

export default NotFound;
