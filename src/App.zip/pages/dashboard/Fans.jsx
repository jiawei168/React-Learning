import React from "react";

const Fans = () => {
  return <div>粉丝列表</div>;
};

export default Fans;
