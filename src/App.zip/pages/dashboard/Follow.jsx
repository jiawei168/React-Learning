import React from "react";

const Follow = () => {
  return <div>关注列表</div>;
};

export default Follow;
