import React from "react";
import { Outlet, NavLink, useLocation } from "react-router-dom";
import "../../app.css";
const Dashboard = () => {
  const location = useLocation();
  const { username, age } = location.state || "";
  return (
    <div>
      <h2>Dashboard</h2>
      <h3>
        Welcome:姓名{username},年龄{age}
      </h3>
      <nav>
        <NavLink to="profile">Profile</NavLink>

        <NavLink to="setting">Setting</NavLink>
      </nav>
      <Outlet />
    </div>
  );
};

export default Dashboard;
