const blogs = [
  {
    id: 1,
    title: "前端工程化入门",
    content:
      "前端工程化是前端开发中非常重要的一部分，它可以帮助我们更好地管理和维护代码。通过使用模块化、组件化等技术，我们可以将复杂的前端项目拆分成多个小模块，提高开发效率和代码的可维护性。同时，工程化还涉及到构建工具的使用，如 Webpack、Rollup 等，它们可以帮助我们对代码进行打包、压缩、优化等操作，提升项目的性能。",
    author: "张三",
    image: "https://example.com/image1.jpg",
    likes: 120,
    views: 500,
    collections: 30,
  },
  {
    id: 2,
    title: "Webpack 高级配置技巧",
    content:
      "Webpack 是前端工程化中常用的构建工具之一，它提供了丰富的配置选项，可以帮助我们实现各种复杂的构建需求。例如，通过配置多入口文件，我们可以同时构建多个页面；使用插件和加载器，可以对代码进行压缩、优化、代码分割等操作。在本篇博客中，我将详细介绍 Webpack 的高级配置技巧，帮助你更好地掌握 Webpack 的使用。",
    author: "李四",
    image: "https://example.com/image2.jpg",
    likes: 80,
    views: 300,
    collections: 20,
  },
  {
    id: 3,
    title: "前端性能优化实践",
    content:
      "前端性能优化是前端工程化中不可或缺的一部分。通过优化代码结构、减少 HTTP 请求、使用缓存等手段，可以显著提升页面的加载速度和用户体验。在本篇博客中，我将分享一些前端性能优化的实践方法，包括图片懒加载、代码分割、缓存策略等，帮助你打造高性能的前端项目。",
    author: "王五",
    image: "https://example.com/image3.jpg",
    likes: 150,
    views: 600,
    collections: 40,
  },
  {
    id: 4,
    title: "CSS 预处理器的使用与比较",
    content:
      "CSS 预处理器如 Sass、Less 和 Stylus，为前端开发带来了更多的便利和灵活性。它们支持变量、嵌套、混合等功能，可以让我们更高效地编写和维护 CSS 代码。在本篇博客中，我将详细介绍这些 CSS 预处理器的使用方法，并对它们进行比较，帮助你选择最适合自己的工具。",
    author: "赵六",
    image: "https://example.com/image4.jpg",
    likes: 90,
    views: 400,
    collections: 25,
  },
  {
    id: 5,
    title: "前端代码规范的重要性",
    content:
      "前端代码规范是前端工程化的重要组成部分，它可以帮助团队成员更好地协作和维护代码。通过制定统一的代码规范，可以避免代码风格的不一致，提高代码的可读性和可维护性。在本篇博客中，我将介绍一些常见的前端代码规范，包括 HTML、CSS 和 JavaScript 的规范，并分享如何在团队中推广和执行代码规范。",
    author: "孙七",
    image: "https://example.com/image5.jpg",
    likes: 100,
    views: 450,
    collections: 35,
  },
  {
    id: 6,
    title: "前端自动化测试入门",
    content:
      "前端自动化测试是前端工程化中越来越重要的一部分。通过编写测试用例，我们可以对前端代码进行自动化的测试，确保代码的质量和稳定性。在本篇博客中，我将介绍前端自动化测试的基本概念和常用工具，如 Jest、Mocha 等，并分享如何在项目中引入自动化测试。",
    author: "周八",
    image: "https://example.com/image6.jpg",
    likes: 70,
    views: 350,
    collections: 15,
  },
  {
    id: 7,
    title: "前端项目中的版本控制",
    content:
      "版本控制是前端工程化中不可或缺的一部分，它可以帮助我们更好地管理代码的变更历史和协作开发。Git 是目前最常用的版本控制系统之一，它提供了丰富的功能，如分支管理、冲突解决、历史回溯等。在本篇博客中，我将详细介绍 Git 的基本使用方法和一些高级技巧，帮助你更好地掌握版本控制。",
    author: "吴九",
    image: "https://example.com/image7.jpg",
    likes: 110,
    views: 550,
    collections: 30,
  },
  {
    id: 8,
    title: "前端组件库的构建与优化",
    content:
      "前端组件库是前端工程化的重要组成部分，它可以帮助我们快速构建和复用组件，提高开发效率。通过使用 React、Vue 等框架，我们可以轻松地构建出可复用的组件库。在本篇博客中，我将介绍如何构建一个高效的前端组件库，并分享一些优化组件库性能的方法。",
    author: "郑十",
    image: "https://example.com/image8.jpg",
    likes: 130,
    views: 700,
    collections: 50,
  },
  {
    id: 9,
    title: "前端工程化的持续集成与持续部署",
    content:
      "持续集成和持续部署（CI/CD）是前端工程化中的重要实践，它们可以帮助我们自动化地构建、测试和部署前端项目，提高开发效率和代码质量。在本篇博客中，我将介绍如何在前端项目中实现 CI/CD，包括使用 Jenkins、GitHub Actions 等工具的配置方法。",
    author: "钱十一",
    image: "https://example.com/image9.jpg",
    likes: 140,
    views: 800,
    collections: 60,
  },
  {
    id: 10,
    title: "前端工程化中的代码分割与懒加载",
    content:
      "代码分割和懒加载是前端工程化中常用的优化手段，它们可以帮助我们减少页面的初始加载时间，提高用户体验。通过使用 Webpack 的代码分割功能和 React 的懒加载机制，我们可以将代码分割成多个小块，按需加载。在本篇博客中，我将详细介绍代码分割和懒加载的实现方法和注意事项。",
    author: "孔十二",
    image: "https://example.com/image10.jpg",
    likes: 160,
    views: 900,
    collections: 70,
  },
];

export default blogs;
